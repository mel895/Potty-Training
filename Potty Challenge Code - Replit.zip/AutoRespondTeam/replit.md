# The Potty Challenge - Interactive Potty Training App

## Overview

The Potty Challenge is an interactive potty training app designed to guide parents through the potty training process with their children. The application features a comprehensive readiness assessment, reward-based tracking system, and timer-based progress monitoring. It combines child-friendly educational elements with parent-focused productivity tools, drawing inspiration from apps like ABCmouse and Khan Academy Kids. The app provides structured guidance through potty training sessions with visual progress tracking, achievement badges, and customizable reward systems to motivate both children and parents throughout the process.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: Local React state with React Query for server state management
- **UI Components**: Radix UI primitives with shadcn/ui components for consistent, accessible design
- **Styling**: Tailwind CSS with custom design system featuring child-friendly colors and typography
- **Design System**: Custom theme with Inter font, cheerful blue primary colors, and card-based layouts optimized for large touch targets

### Backend Architecture
- **Server**: Express.js with TypeScript for API endpoints
- **Build System**: ESBuild for production bundling with Vite for development
- **Storage Interface**: Abstracted storage layer with in-memory implementation (MemStorage class)
- **Session Management**: Express sessions with PostgreSQL session store integration
- **API Design**: RESTful endpoints with `/api` prefix and structured error handling

### Data Layer
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Zod schemas for runtime validation and type inference
- **Connection**: Neon Database serverless PostgreSQL integration
- **Data Models**: Comprehensive schema covering readiness criteria, reward tracking, timer state, and wet/dry check records

### Component Architecture
- **Progress Management**: Multi-step wizard with stepper component for guided flow
- **Timer System**: Real-time countdown with Web Audio API notification sounds
- **Reward System**: Star-based economy with redeemable rewards and visual progress tracking
- **Assessment Tools**: Interactive readiness checklist with visual completion indicators
- **Responsive Design**: Mobile-first approach with touch-optimized interactions

### Authentication and State
- **Session Handling**: Server-side session management with secure cookie storage
- **Data Persistence**: Local state management with planned database integration
- **Form Handling**: React Hook Form with Zod validation for type-safe form processing

## External Dependencies

### Database and Storage
- **Neon Database**: Serverless PostgreSQL hosting for production data storage
- **Drizzle ORM**: Type-safe database toolkit for schema management and queries
- **Connect-pg-simple**: PostgreSQL session store for Express sessions

### UI and Styling
- **Radix UI**: Headless UI primitives for accessible component foundation
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Icon library for consistent iconography
- **Google Fonts**: Inter font family for typography

### Development and Build Tools
- **Vite**: Fast build tool and development server with React plugin
- **TypeScript**: Static typing for enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Development environment plugins for Replit platform

### State and Data Management
- **TanStack React Query**: Server state management and caching
- **React Hook Form**: Form state management with validation
- **Zod**: Schema validation library for runtime type checking
- **Date-fns**: Date manipulation and formatting utilities

### Media and Assets
- **Generated Images**: Custom reward images stored in attached_assets directory
- **Web Audio API**: Browser-native audio for timer notifications and feedback sounds