import { useState, useEffect } from "react";
import { Play, Pause, RotateCcw, Check, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { type TimerState } from "@shared/schema";

interface TimerCardProps {
  timer: TimerState;
  onUpdateTimer: (timer: Partial<TimerState>) => void;
  onCheckResult: (isDry: boolean) => void;
}

export default function TimerCard({ timer, onUpdateTimer, onCheckResult }: TimerCardProps) {
  const [localSeconds, setLocalSeconds] = useState(timer.secondsLeft);

  useEffect(() => {
    setLocalSeconds(timer.secondsLeft);
  }, [timer.secondsLeft]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (timer.isRunning && localSeconds > 0) {
      interval = setInterval(() => {
        setLocalSeconds(prev => {
          const newSeconds = prev - 1;
          onUpdateTimer({ secondsLeft: newSeconds });
          
          // Play notification sound when timer reaches 0
          if (newSeconds === 0) {
            try {
              // Create a simple notification sound using Web Audio API
              const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
              const oscillator = audioContext.createOscillator();
              const gainNode = audioContext.createGain();
              
              oscillator.connect(gainNode);
              gainNode.connect(audioContext.destination);
              
              oscillator.frequency.value = 800; // Bell-like tone
              oscillator.type = 'sine';
              
              gainNode.gain.setValueAtTime(0, audioContext.currentTime);
              gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.1);
              gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.5);
              
              oscillator.start(audioContext.currentTime);
              oscillator.stop(audioContext.currentTime + 0.5);
              
              // Clean up audio context after sound completes
              setTimeout(() => {
                audioContext.close().catch(() => {});
              }, 600);
            } catch (error) {
              console.log('Audio notification not available');
            }
          }
          
          return newSeconds;
        });
      }, 1000);
    } else if (localSeconds === 0 && timer.isRunning) {
      onUpdateTimer({ isRunning: false });
    }

    return () => clearInterval(interval);
  }, [timer.isRunning, localSeconds, onUpdateTimer]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartPause = () => {
    onUpdateTimer({ isRunning: !timer.isRunning });
  };

  const handleReset = () => {
    // Check for short timer parameter for testing
    const urlParams = new URLSearchParams(window.location.search);
    const shortTimer = urlParams.has('shortTimer');
    const timerDuration = shortTimer ? 5 : 10 * 60; // 5 seconds for testing, 10 minutes normal
    
    onUpdateTimer({ isRunning: false, secondsLeft: timerDuration });
    setLocalSeconds(timerDuration);
  };

  const handleCheckResult = (isDry: boolean) => {
    // Play success sound for dry checks
    if (isDry) {
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        // Play a cheerful ascending tone for success
        oscillator.frequency.setValueAtTime(523, audioContext.currentTime); // C5
        oscillator.frequency.setValueAtTime(659, audioContext.currentTime + 0.1); // E5
        oscillator.frequency.setValueAtTime(784, audioContext.currentTime + 0.2); // G5
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0, audioContext.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.2, audioContext.currentTime + 0.05);
        gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.4);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.4);
        
        // Clean up audio context after sound completes
        setTimeout(() => {
          audioContext.close().catch(() => {});
        }, 500);
      } catch (error) {
        console.log('Audio feedback not available');
      }
    }
    
    onCheckResult(isDry);
    
    // Always advance to next check number after recording result
    // This ensures proper completion state when all 5 checks are done
    const nextCheck = timer.currentCheck + 1;
    
    if (nextCheck <= 5) {
      // Move to next check with reset timer
      const urlParams = new URLSearchParams(window.location.search);
      const shortTimer = urlParams.has('shortTimer');
      const timerDuration = shortTimer ? 5 : 10 * 60;
      
      setLocalSeconds(timerDuration);
      onUpdateTimer({ 
        currentCheck: nextCheck, 
        secondsLeft: timerDuration, 
        isRunning: false 
      });
    } else {
      // All checks complete, set to check 6 to trigger completion state
      onUpdateTimer({ currentCheck: 6 });
    }
  };

  const isTimeUp = localSeconds === 0;
  const allChecksComplete = timer.currentCheck > 5;

  return (
    <Card data-testid="timer-card">
      <CardHeader>
        <CardTitle className="text-center">
          {allChecksComplete ? "All Checks Complete!" : `Check #${timer.currentCheck}`}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        {!allChecksComplete && (
          <>
            {/* Timer Display */}
            <div className="text-6xl font-bold text-primary" data-testid="timer-display">
              {formatTime(localSeconds)}
            </div>
            
            {/* Timer Controls */}
            <div className="flex gap-2 justify-center">
              <Button
                variant={timer.isRunning ? "secondary" : "default"}
                size="lg"
                onClick={handleStartPause}
                data-testid={timer.isRunning ? "button-pause-timer" : "button-start-timer"}
              >
                {timer.isRunning ? <Pause className="w-5 h-5 mr-2" /> : <Play className="w-5 h-5 mr-2" />}
                {timer.isRunning ? "Pause" : "Start"}
              </Button>
              <Button variant="outline" onClick={handleReset} data-testid="button-reset-timer">
                <RotateCcw className="w-5 h-5" />
              </Button>
            </div>
          </>
        )}

        {/* Time's Up Check */}
        {isTimeUp && !allChecksComplete && (
          <div className="space-y-3 pt-4 border-t">
            <p className="font-semibold text-foreground">Time's up! Check your child:</p>
            <div className="flex gap-2 justify-center">
              <Button
                onClick={() => handleCheckResult(true)}
                className="bg-chart-1 hover:bg-chart-1/90"
                data-testid={`button-dry-check-${timer.currentCheck}`}
              >
                <Check className="w-4 h-4 mr-2" />
                Dry (+1 ⭐)
              </Button>
              <Button
                onClick={() => handleCheckResult(false)}
                variant="destructive"
                data-testid={`button-wet-check-${timer.currentCheck}`}
              >
                <X className="w-4 h-4 mr-2" />
                Wet
              </Button>
            </div>
          </div>
        )}

        {/* All Checks Complete */}
        {allChecksComplete && (
          <div className="space-y-3">
            <div className="text-4xl">🎉</div>
            <p className="text-lg font-semibold text-chart-1">Great job today!</p>
            <Badge variant="outline" className="text-base py-2 px-4">
              All 5 checks completed
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
}