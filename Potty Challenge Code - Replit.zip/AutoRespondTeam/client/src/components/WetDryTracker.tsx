import { useState, useEffect } from "react";
import { Play, Pause, RotateCcw, Check, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { type WetDryCheck, type Reward, TARGET_CHECKS } from "@shared/schema";

interface WetDryTrackerProps {
  wetDryChecks: WetDryCheck[];
  selectedReward?: Reward;
  onUpdateCheck: (checkNumber: number, isDry: boolean) => void;
  onComplete: () => void;
  onBack: () => void;
}

export default function WetDryTracker({ 
  wetDryChecks, 
  selectedReward, 
  onUpdateCheck, 
  onComplete, 
  onBack 
}: WetDryTrackerProps) {
  const [timeRemaining, setTimeRemaining] = useState(10 * 60); // 10 minutes in seconds
  const [isRunning, setIsRunning] = useState(false);
  const [currentCheck, setCurrentCheck] = useState(1);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(time => time - 1);
      }, 1000);
    } else if (timeRemaining === 0) {
      setIsRunning(false);
      // Auto advance to next check
      if (currentCheck < TARGET_CHECKS) {
        setCurrentCheck(prev => prev + 1);
        setTimeRemaining(10 * 60);
      }
    }

    return () => clearInterval(interval);
  }, [isRunning, timeRemaining, currentCheck]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartPause = () => {
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeRemaining(10 * 60);
  };

  const handleCheckResult = (isDry: boolean) => {
    onUpdateCheck(currentCheck, isDry);
    if (currentCheck < TARGET_CHECKS) {
      setCurrentCheck(prev => prev + 1);
      setTimeRemaining(10 * 60);
      setIsRunning(false);
    }
  };

  const completedChecks = wetDryChecks.filter(check => check.isCompleted).length;
  const allChecksComplete = completedChecks === TARGET_CHECKS;

  return (
    <div className="space-y-6" data-testid="wet-dry-tracker">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-foreground">Wet or Dry Tracking</h2>
        <p className="text-muted-foreground">Check every 10 minutes to see if your child stayed dry</p>
        {selectedReward && (
          <div className="flex items-center justify-center gap-2">
            <span className="text-sm text-muted-foreground">Working for:</span>
            <Badge variant="outline" className="gap-2">
              <img src={selectedReward.image} alt={selectedReward.name} className="w-4 h-4 rounded" />
              {selectedReward.name}
            </Badge>
          </div>
        )}
      </div>

      {/* Timer Display */}
      <Card className="mx-auto max-w-md">
        <CardHeader>
          <CardTitle className="text-center">Check #{currentCheck}</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <div className="text-6xl font-bold text-primary" data-testid="timer-display">
            {formatTime(timeRemaining)}
          </div>
          
          <div className="flex gap-2 justify-center">
            <Button
              variant={isRunning ? "secondary" : "default"}
              size="lg"
              onClick={handleStartPause}
              disabled={currentCheck > TARGET_CHECKS}
              data-testid={isRunning ? "button-pause-timer" : "button-start-timer"}
            >
              {isRunning ? <Pause className="w-5 h-5 mr-2" /> : <Play className="w-5 h-5 mr-2" />}
              {isRunning ? "Pause" : "Start"}
            </Button>
            <Button variant="outline" onClick={handleReset} data-testid="button-reset-timer">
              <RotateCcw className="w-5 h-5" />
            </Button>
          </div>

          {timeRemaining === 0 && currentCheck <= TARGET_CHECKS && (
            <div className="space-y-3 pt-4 border-t">
              <p className="font-semibold text-foreground">Time's up! Check your child:</p>
              <div className="flex gap-2 justify-center">
                <Button
                  onClick={() => handleCheckResult(true)}
                  className="bg-chart-1 hover:bg-chart-1/90"
                  data-testid={`button-dry-check-${currentCheck}`}
                >
                  <Check className="w-4 h-4 mr-2" />
                  Dry
                </Button>
                <Button
                  onClick={() => handleCheckResult(false)}
                  variant="destructive"
                  data-testid={`button-wet-check-${currentCheck}`}
                >
                  <X className="w-4 h-4 mr-2" />
                  Wet
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Progress Checks */}
      <div className="space-y-2">
        <h3 className="text-lg font-semibold text-center">Progress</h3>
        <div className={`grid gap-2`} style={{ gridTemplateColumns: `repeat(${TARGET_CHECKS}, minmax(0, 1fr))` }}>
          {Array.from({ length: TARGET_CHECKS }, (_, i) => i + 1).map((checkNum) => {
            const check = wetDryChecks.find(c => c.checkNumber === checkNum);
            const isActive = checkNum === currentCheck;
            const isCompleted = check?.isCompleted;
            const isDry = check?.isDry;

            return (
              <Card 
                key={checkNum} 
                className={`text-center ${isActive ? 'ring-2 ring-primary' : ''}`}
                data-testid={`check-status-${checkNum}`}
              >
                <CardContent className="p-3">
                  <div className="text-sm font-medium">Check {checkNum}</div>
                  <div className="mt-2">
                    {isCompleted ? (
                      <div className={`w-8 h-8 rounded-full mx-auto flex items-center justify-center ${
                        isDry ? 'bg-chart-1 text-white' : 'bg-destructive text-white'
                      }`}>
                        {isDry ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                      </div>
                    ) : (
                      <div className={`w-8 h-8 rounded-full mx-auto border-2 ${
                        isActive ? 'border-primary bg-primary/10' : 'border-muted bg-muted'
                      }`} />
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {allChecksComplete && (
        <div className="text-center space-y-4">
          <div className="p-4 bg-chart-1/10 rounded-lg border border-chart-1/20">
            <h3 className="font-semibold text-chart-1 mb-2">Congratulations!</h3>
            <p className="text-muted-foreground">You've completed all {TARGET_CHECKS} checks. Great job!</p>
          </div>
          <div className="flex gap-4 justify-center">
            <Button variant="outline" onClick={onBack} data-testid="button-back-to-rewards">
              Back to Rewards
            </Button>
            <Button onClick={onComplete} size="lg" data-testid="button-complete-session">
              Complete Session
            </Button>
          </div>
        </div>
      )}

      {!allChecksComplete && (
        <div className="text-center">
          <Button variant="outline" onClick={onBack} data-testid="button-back-to-rewards">
            Back to Rewards
          </Button>
        </div>
      )}
    </div>
  );
}