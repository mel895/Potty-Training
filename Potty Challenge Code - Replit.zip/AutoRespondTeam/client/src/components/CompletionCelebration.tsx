import { PartyPopper, RotateCcw, Home } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { type Reward, type WetDryCheck } from "@shared/schema";

interface CompletionCelebrationProps {
  selectedReward?: Reward;
  wetDryChecks: WetDryCheck[];
  childName: string;
  onStartNew: () => void;
  onHome: () => void;
}

export default function CompletionCelebration({ 
  selectedReward, 
  wetDryChecks, 
  childName,
  onStartNew, 
  onHome 
}: CompletionCelebrationProps) {
  const dryChecks = wetDryChecks.filter(check => check.isDry === true).length;
  const totalChecks = wetDryChecks.filter(check => check.isCompleted).length;
  const successRate = Math.round((dryChecks / totalChecks) * 100);

  return (
    <div className="space-y-6 text-center" data-testid="completion-celebration">
      <div className="space-y-4">
        <div className="text-6xl">🎉</div>
        <h2 className="text-3xl font-bold text-foreground">Congratulations!</h2>
        <p className="text-lg text-muted-foreground">
          {childName ? `${childName} did` : "You did"} an amazing job with potty training!
        </p>
      </div>

      <Card className="max-w-md mx-auto">
        <CardContent className="p-6 space-y-4">
          <div className="space-y-2">
            <h3 className="text-xl font-semibold">Session Results</h3>
            <div className="text-3xl font-bold text-chart-1">{successRate}%</div>
            <p className="text-sm text-muted-foreground">
              {dryChecks} out of {totalChecks} checks were dry
            </p>
          </div>

          {selectedReward && (
            <div className="space-y-2 pt-4 border-t">
              <p className="font-medium text-foreground">Time for your reward!</p>
              <Badge variant="outline" className="gap-2 text-base py-2 px-4">
                <img src={selectedReward.image} alt={selectedReward.name} className="w-6 h-6 rounded" />
                {selectedReward.name}
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-5 gap-2 max-w-sm mx-auto">
        {wetDryChecks.map((check, index) => (
          <div
            key={index}
            className={`aspect-square rounded-lg flex items-center justify-center text-white font-bold ${
              check.isDry === true ? 'bg-chart-1' : check.isDry === false ? 'bg-destructive' : 'bg-muted'
            }`}
            data-testid={`final-check-${index + 1}`}
          >
            {index + 1}
          </div>
        ))}
      </div>

      <div className="flex gap-4 justify-center flex-wrap">
        <Button 
          variant="outline" 
          onClick={onStartNew}
          data-testid="button-start-new-session"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Start New Session
        </Button>
        <Button 
          onClick={onHome}
          data-testid="button-home"
        >
          <Home className="w-4 h-4 mr-2" />
          Home
        </Button>
      </div>
    </div>
  );
}