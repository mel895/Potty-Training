import { Check } from "lucide-react";

interface ProgressStepperProps {
  currentStep: "readiness" | "reward" | "tracking" | "completed";
}

const steps = [
  { key: "readiness", label: "Readiness Check", number: 1 },
  { key: "reward", label: "Choose Reward", number: 2 },
  { key: "tracking", label: "Track Progress", number: 3 },
  { key: "completed", label: "Complete", number: 4 },
];

export default function ProgressStepper({ currentStep }: ProgressStepperProps) {
  const currentStepIndex = steps.findIndex(step => step.key === currentStep);

  return (
    <div className="w-full py-4" data-testid="progress-stepper">
      <div className="flex items-center justify-center">
        {steps.map((step, index) => {
          const isCompleted = index < currentStepIndex;
          const isCurrent = index === currentStepIndex;
          const isLast = index === steps.length - 1;

          return (
            <div key={step.key} className="flex items-center">
              <div 
                className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium ${
                  isCompleted 
                    ? 'bg-chart-1 text-white'
                    : isCurrent 
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground'
                }`}
                data-testid={`step-${step.key}`}
              >
                {isCompleted ? <Check className="w-4 h-4" /> : step.number}
              </div>
              
              <span className={`ml-2 text-sm font-medium hidden sm:inline ${
                isCurrent ? 'text-primary' : isCompleted ? 'text-chart-1' : 'text-muted-foreground'
              }`}>
                {step.label}
              </span>

              {!isLast && (
                <div className={`w-8 sm:w-16 h-0.5 mx-2 sm:mx-4 ${
                  isCompleted ? 'bg-chart-1' : 'bg-muted'
                }`} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}