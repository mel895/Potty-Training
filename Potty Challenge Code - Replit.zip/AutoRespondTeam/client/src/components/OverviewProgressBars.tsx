import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, Star } from "lucide-react";
import { type ReadinessCriteria, type WetDryCheck, TARGET_CHECKS } from "@shared/schema";

interface OverviewProgressBarsProps {
  readiness: ReadinessCriteria;
  checks: WetDryCheck[];
  stars: number;
  activeRewardCost?: number;
  activeRewardName?: string;
}

export default function OverviewProgressBars({ 
  readiness, 
  checks, 
  stars, 
  activeRewardCost,
  activeRewardName 
}: OverviewProgressBarsProps) {
  // Calculate readiness percentage
  const readinessValues = Object.values(readiness);
  const readinessCompleted = readinessValues.filter(Boolean).length;
  const readinessPercent = Math.round((readinessCompleted / readinessValues.length) * 100);

  // Calculate today's checks (with legacy state protection)
  const completedChecks = Math.min(checks.filter(check => check.isCompleted).length, TARGET_CHECKS);
  const dryChecks = Math.min(checks.filter(check => check.isDry === true).length, TARGET_CHECKS);
  const checksPercent = Math.min(Math.round((completedChecks / TARGET_CHECKS) * 100), 100);

  // Calculate reward progress
  const rewardPercent = activeRewardCost ? Math.min(Math.round((stars / activeRewardCost) * 100), 100) : 0;

  // Individual skill data for progress bars
  const skillLabels = {
    canStayDry: "Can Stay Dry",
    canFollowInstructions: "Follows Instructions", 
    canRecognizeAccidents: "Recognizes Accidents",
    canSitForOneMinute: "Sits for 1 Minute",
    canTellWetFromDry: "Tells Wet from Dry",
    canPullPantsUpDown: "Pulls Pants Up/Down"
  };

  return (
    <Card data-testid="overview-progress">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          Progress Overview
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Individual Skill Progress */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Individual Skills</span>
            <Badge variant="outline" data-testid="readiness-completion">
              {readinessCompleted}/{readinessValues.length} Complete
            </Badge>
          </div>
          
          {/* Individual skill progress bars */}
          <div className="space-y-3">
            {Object.entries(skillLabels).map(([skillKey, skillLabel]) => {
              const isCompleted = readiness[skillKey as keyof ReadinessCriteria];
              const skillPercent = isCompleted ? 100 : 0;
              
              return (
                <div key={skillKey} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-muted-foreground">{skillLabel}</span>
                    <div className="flex items-center gap-1">
                      {isCompleted ? (
                        <CheckCircle className="w-3 h-3 text-chart-1" />
                      ) : (
                        <div className="w-3 h-3 rounded-full border border-muted-foreground/30" />
                      )}
                    </div>
                  </div>
                  <Progress 
                    value={skillPercent} 
                    className="h-1.5" 
                    data-testid={`skill-progress-${skillKey}`} 
                  />
                </div>
              );
            })}
          </div>
          
          <p className="text-xs text-muted-foreground text-center pt-2 border-t">
            {readinessPercent}% ready for potty training
          </p>
        </div>

        {/* Today's Checks */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Today's Checks
            </span>
            <div className="flex gap-2">
              <Badge variant="outline" className="bg-chart-1/10 text-chart-1" data-testid="dry-count">
                {dryChecks} Dry
              </Badge>
              <Badge variant="outline" data-testid="checks-completion">
                {completedChecks}/{TARGET_CHECKS}
              </Badge>
            </div>
          </div>
          <Progress value={checksPercent} className="h-2" data-testid="checks-progress" />
          <p className="text-xs text-muted-foreground">
            {completedChecks === TARGET_CHECKS ? "All checks complete!" : `${TARGET_CHECKS - completedChecks} checks remaining`}
          </p>
        </div>

        {/* Active Reward Progress */}
        {activeRewardName && activeRewardCost && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-500" />
                {activeRewardName}
              </span>
              <Badge variant="outline" data-testid="stars-count">
                {stars}/{activeRewardCost} ⭐
              </Badge>
            </div>
            <Progress value={rewardPercent} className="h-2" data-testid="reward-progress" />
            <p className="text-xs text-muted-foreground">
              {stars >= activeRewardCost 
                ? "Ready to redeem!" 
                : `${activeRewardCost - stars} more stars needed`}
            </p>
          </div>
        )}

        {/* Stars Balance */}
        <div className="pt-4 border-t">
          <div className="flex items-center justify-between">
            <span className="font-medium">Your Stars</span>
            <div className="flex items-center gap-1 text-lg font-bold text-yellow-500" data-testid="total-stars">
              <Star className="w-5 h-5 fill-current" />
              {stars}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}