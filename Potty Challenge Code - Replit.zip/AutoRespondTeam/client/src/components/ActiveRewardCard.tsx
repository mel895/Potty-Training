import { Star, Gift } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { type Reward } from "@shared/schema";

interface ActiveRewardCardProps {
  activeReward?: Reward;
  stars: number;
  onChangeReward: () => void;
  onRedeem?: () => void;
}

export default function ActiveRewardCard({ 
  activeReward, 
  stars, 
  onChangeReward,
  onRedeem 
}: ActiveRewardCardProps) {
  const canRedeem = activeReward && stars >= activeReward.cost;

  if (!activeReward) {
    return (
      <Card data-testid="no-active-reward">
        <CardContent className="p-6 text-center space-y-4">
          <Gift className="w-12 h-12 mx-auto text-muted-foreground" />
          <div className="space-y-2">
            <h3 className="font-semibold">No Reward Selected</h3>
            <p className="text-sm text-muted-foreground">
              Choose a reward to work towards!
            </p>
          </div>
          <Button onClick={onChangeReward} data-testid="button-choose-reward">
            Browse Rewards
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="active-reward-card">
      <CardHeader>
        <CardTitle className="text-center text-lg">Current Goal</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Reward Display */}
        <div className="text-center space-y-3">
          <div className="w-24 h-24 mx-auto rounded-lg overflow-hidden bg-muted">
            <img 
              src={activeReward.image} 
              alt={activeReward.name}
              className="w-full h-full object-cover"
              data-testid="active-reward-image"
            />
          </div>
          <div>
            <h3 className="font-semibold text-lg" data-testid="active-reward-name">
              {activeReward.name}
            </h3>
            <Badge 
              variant="outline" 
              className="mt-1"
              data-testid="active-reward-cost"
            >
              <Star className="w-3 h-3 mr-1 fill-current text-yellow-500" />
              {activeReward.cost} Stars
            </Badge>
          </div>
        </div>

        {/* Progress */}
        <div className="text-center space-y-2">
          <div className="text-2xl font-bold" data-testid="stars-vs-cost">
            {stars} / {activeReward.cost} ⭐
          </div>
          {canRedeem ? (
            <p className="text-sm text-chart-1 font-medium">Ready to redeem! 🎉</p>
          ) : (
            <p className="text-sm text-muted-foreground">
              {activeReward.cost - stars} more stars needed
            </p>
          )}
        </div>

        {/* Actions */}
        <div className="space-y-2">
          {canRedeem && onRedeem && (
            <Button 
              className="w-full bg-chart-1 hover:bg-chart-1/90"
              onClick={onRedeem}
              data-testid="button-redeem-reward"
            >
              <Gift className="w-4 h-4 mr-2" />
              Redeem Now!
            </Button>
          )}
          <Button 
            variant="outline" 
            className="w-full"
            onClick={onChangeReward}
            data-testid="button-change-reward"
          >
            Change Reward
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}