import { useState } from "react";
import TimerCard from "../TimerCard";
import { type TimerState } from "@shared/schema";

export default function TimerCardExample() {
  const [timer, setTimer] = useState<TimerState>({
    isRunning: false,
    currentCheck: 3,
    secondsLeft: 5 * 60, // 5 minutes for demo
  });

  const handleUpdateTimer = (updates: Partial<TimerState>) => {
    setTimer(prev => ({ ...prev, ...updates }));
  };

  const handleCheckResult = (isDry: boolean) => {
    console.log(`Check ${timer.currentCheck} result:`, isDry ? "Dry (+1 star)" : "Wet");
  };

  return (
    <div className="p-6 max-w-md mx-auto">
      <TimerCard 
        timer={timer}
        onUpdateTimer={handleUpdateTimer}
        onCheckResult={handleCheckResult}
      />
    </div>
  );
}