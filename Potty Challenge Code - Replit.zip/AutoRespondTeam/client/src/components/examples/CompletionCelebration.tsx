import CompletionCelebration from "../CompletionCelebration";
import { type WetDryCheck, type Reward } from "@shared/schema";

// Import reward image for example
import iceCreamImage from "@assets/generated_images/Ice_cream_treat_reward_de19c07a.png";

export default function CompletionCelebrationExample() {
  const selectedReward: Reward = {
    id: "ice-cream",
    name: "Ice Cream Treat",
    image: iceCreamImage,
    selected: true,
  };

  const wetDryChecks: WetDryCheck[] = [
    { checkNumber: 1, timestamp: new Date(), isDry: true, isCompleted: true },
    { checkNumber: 2, timestamp: new Date(), isDry: true, isCompleted: true },
    { checkNumber: 3, timestamp: new Date(), isDry: false, isCompleted: true },
    { checkNumber: 4, timestamp: new Date(), isDry: true, isCompleted: true },
    { checkNumber: 5, timestamp: new Date(), isDry: true, isCompleted: true },
  ];

  const handleStartNew = () => {
    console.log("Starting new potty training session");
  };

  const handleHome = () => {
    console.log("Going to home page");
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <CompletionCelebration 
        selectedReward={selectedReward}
        wetDryChecks={wetDryChecks}
        childName="Emma"
        onStartNew={handleStartNew}
        onHome={handleHome}
      />
    </div>
  );
}