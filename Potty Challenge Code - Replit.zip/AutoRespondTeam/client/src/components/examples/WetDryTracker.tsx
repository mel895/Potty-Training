import { useState } from "react";
import WetDryTracker from "../WetDryTracker";
import { type WetDryCheck, type Reward } from "@shared/schema";

// Import one reward image for example
import dinnerImage from "@assets/generated_images/Family_dinner_reward_27c37eee.png";

export default function WetDryTrackerExample() {
  const [wetDryChecks, setWetDryChecks] = useState<WetDryCheck[]>([
    { checkNumber: 1, timestamp: new Date(), isDry: true, isCompleted: true },
    { checkNumber: 2, timestamp: new Date(), isDry: false, isCompleted: true },
    { checkNumber: 3, timestamp: new Date(), isCompleted: false },
    { checkNumber: 4, timestamp: new Date(), isCompleted: false },
    { checkNumber: 5, timestamp: new Date(), isCompleted: false },
  ]);

  const selectedReward: Reward = {
    id: "dinner",
    name: "Family Dinner",
    image: dinnerImage,
    selected: true,
  };

  const handleUpdateCheck = (checkNumber: number, isDry: boolean) => {
    setWetDryChecks(prev => 
      prev.map(check => 
        check.checkNumber === checkNumber 
          ? { ...check, isDry, isCompleted: true }
          : check
      )
    );
  };

  const handleComplete = () => {
    console.log("Session completed!");
  };

  const handleBack = () => {
    console.log("Going back to reward selection");
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <WetDryTracker 
        wetDryChecks={wetDryChecks}
        selectedReward={selectedReward}
        onUpdateCheck={handleUpdateCheck}
        onComplete={handleComplete}
        onBack={handleBack}
      />
    </div>
  );
}