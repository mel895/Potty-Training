import { useState } from "react";
import ActiveRewardCard from "../ActiveRewardCard";
import { type Reward } from "@shared/schema";

// Import reward image for example
import iceCreamImage from "@assets/generated_images/Ice_cream_treat_reward_de19c07a.png";

export default function ActiveRewardCardExample() {
  const [stars] = useState(7);
  
  const activeReward: Reward = {
    id: "ice-cream",
    name: "Ice Cream Treat",
    image: iceCreamImage,
    cost: 5,
  };

  const handleChangeReward = () => {
    console.log("Opening reward selection");
  };

  const handleRedeem = () => {
    console.log("Redeeming reward:", activeReward.name);
  };

  return (
    <div className="p-6 max-w-sm mx-auto">
      <ActiveRewardCard 
        activeReward={activeReward}
        stars={stars}
        onChangeReward={handleChangeReward}
        onRedeem={handleRedeem}
      />
    </div>
  );
}