import { useState } from "react";
import ProgressStepper from "../ProgressStepper";
import { Button } from "@/components/ui/button";

export default function ProgressStepperExample() {
  const [currentStep, setCurrentStep] = useState<"readiness" | "reward" | "tracking" | "completed">("reward");

  const steps: Array<"readiness" | "reward" | "tracking" | "completed"> = ["readiness", "reward", "tracking", "completed"];
  const currentIndex = steps.indexOf(currentStep);

  const goNext = () => {
    if (currentIndex < steps.length - 1) {
      setCurrentStep(steps[currentIndex + 1]);
    }
  };

  const goPrev = () => {
    if (currentIndex > 0) {
      setCurrentStep(steps[currentIndex - 1]);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <ProgressStepper currentStep={currentStep} />
      
      <div className="flex gap-4 justify-center">
        <Button 
          variant="outline" 
          onClick={goPrev} 
          disabled={currentIndex === 0}
        >
          Previous
        </Button>
        <Button 
          onClick={goNext} 
          disabled={currentIndex === steps.length - 1}
        >
          Next
        </Button>
      </div>
    </div>
  );
}