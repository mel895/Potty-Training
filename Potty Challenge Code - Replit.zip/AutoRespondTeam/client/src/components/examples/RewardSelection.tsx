import { useState } from "react";
import RewardSelection from "../RewardSelection";
import { type Reward } from "@shared/schema";

export default function RewardSelectionExample() {
  const [selectedReward, setSelectedReward] = useState<Reward>();

  const handleSelectReward = (reward: Reward) => {
    setSelectedReward(reward);
  };

  const handleNext = () => {
    console.log("Starting tracking with reward:", selectedReward?.name);
  };

  const handleBack = () => {
    console.log("Going back to readiness check");
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <RewardSelection 
        selectedReward={selectedReward}
        onSelectReward={handleSelectReward}
        onNext={handleNext}
        onBack={handleBack}
      />
    </div>
  );
}