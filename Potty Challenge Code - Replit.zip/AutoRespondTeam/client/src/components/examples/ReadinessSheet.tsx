import { useState } from "react";
import ReadinessSheet from "../ReadinessSheet";
import { Button } from "@/components/ui/button";
import { type ReadinessCriteria } from "@shared/schema";

export default function ReadinessSheetExample() {
  const [open, setOpen] = useState(false);
  const [readiness, setReadiness] = useState<ReadinessCriteria>({
    canStayDry: true,
    canFollowInstructions: true,
    canRecognizeAccidents: false,
    canSitForOneMinute: true,
    canTellWetFromDry: false,
    canPullPantsUpDown: true,
  });

  const handleUpdateReadiness = (criteria: keyof ReadinessCriteria, value: boolean) => {
    setReadiness(prev => ({ ...prev, [criteria]: value }));
  };

  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)}>
        Open Readiness Sheet
      </Button>
      
      <ReadinessSheet 
        open={open}
        onOpenChange={setOpen}
        readiness={readiness}
        onUpdateReadiness={handleUpdateReadiness}
      />
    </div>
  );
}