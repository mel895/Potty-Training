import { useState } from "react";
import ReadinessCheck from "../ReadinessCheck";
import { type ReadinessCriteria } from "@shared/schema";

export default function ReadinessCheckExample() {
  const [readiness, setReadiness] = useState<ReadinessCriteria>({
    canStayDry: true,
    canFollowInstructions: true,
    canRecognizeAccidents: false,
    canSitForOneMinute: true,
    canTellWetFromDry: false,
    canPullPantsUpDown: true,
  });

  const handleUpdateReadiness = (criteria: keyof ReadinessCriteria, value: boolean) => {
    setReadiness(prev => ({ ...prev, [criteria]: value }));
  };

  const handleNext = () => {
    console.log("Moving to reward selection");
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <ReadinessCheck 
        readiness={readiness}
        onUpdateReadiness={handleUpdateReadiness}
        onNext={handleNext}
      />
    </div>
  );
}