import { useState } from "react";
import RewardStoreGrid from "../RewardStoreGrid";
import { type Reward } from "@shared/schema";

// Import reward images
import dinnerImage from "@assets/generated_images/Family_dinner_reward_27c37eee.png";
import tvImage from "@assets/generated_images/Extra_TV_time_reward_d1fa939d.png";
import bedtimeImage from "@assets/generated_images/Bedtime_story_reward_5136fab8.png";
import aloneTimeImage from "@assets/generated_images/Alone_time_with_mom_9e8392e6.png";
import iceCreamImage from "@assets/generated_images/Ice_cream_treat_reward_de19c07a.png";
import movieImage from "@assets/generated_images/Movie_coupon_reward_a9c46cf4.png";

export default function RewardStoreGridExample() {
  const [stars] = useState(7);
  const [activeRewardId, setActiveRewardId] = useState<string>("ice-cream");

  const rewards: Reward[] = [
    { id: "dinner", name: "Family Dinner", image: dinnerImage, cost: 3 },
    { id: "tv", name: "Extra TV Time", image: tvImage, cost: 2 },
    { id: "bedtime", name: "Bedtime Story", image: bedtimeImage, cost: 1 },
    { id: "alone-time", name: "Alone Time with Mom", image: aloneTimeImage, cost: 4 },
    { id: "ice-cream", name: "Ice Cream Treat", image: iceCreamImage, cost: 5 },
    { id: "movie", name: "Movie Coupon", image: movieImage, cost: 8 },
  ];

  const handleSetActive = (rewardId: string) => {
    setActiveRewardId(rewardId);
    console.log("Set active reward:", rewardId);
  };

  const handleRedeem = (rewardId: string) => {
    console.log("Redeeming reward:", rewardId);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <RewardStoreGrid 
        rewards={rewards}
        stars={stars}
        activeRewardId={activeRewardId}
        onSetActive={handleSetActive}
        onRedeem={handleRedeem}
      />
    </div>
  );
}