import OverviewProgressBars from "../OverviewProgressBars";
import { type ReadinessCriteria, type WetDryCheck } from "@shared/schema";

export default function OverviewProgressBarsExample() {
  const readiness: ReadinessCriteria = {
    canStayDry: true,
    canFollowInstructions: true,
    canRecognizeAccidents: false,
    canSitForOneMinute: true,
    canTellWetFromDry: true,
    canPullPantsUpDown: false,
  };

  const checks: WetDryCheck[] = [
    { checkNumber: 1, timestamp: new Date(), isDry: true, isCompleted: true },
    { checkNumber: 2, timestamp: new Date(), isDry: true, isCompleted: true },
    { checkNumber: 3, timestamp: new Date(), isDry: false, isCompleted: true },
    { checkNumber: 4, timestamp: new Date(), isCompleted: false },
    { checkNumber: 5, timestamp: new Date(), isCompleted: false },
  ];

  return (
    <div className="p-6 max-w-lg mx-auto">
      <OverviewProgressBars 
        readiness={readiness}
        checks={checks}
        stars={7}
        activeRewardCost={5}
        activeRewardName="Ice Cream Treat"
      />
    </div>
  );
}