import { Star, Gift, Check } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { type Reward } from "@shared/schema";

interface RewardStoreGridProps {
  rewards: Reward[];
  stars: number;
  activeRewardId?: string;
  onSetActive: (rewardId: string) => void;
  onRedeem: (rewardId: string) => void;
}

export default function RewardStoreGrid({ 
  rewards, 
  stars, 
  activeRewardId, 
  onSetActive, 
  onRedeem 
}: RewardStoreGridProps) {
  return (
    <div className="space-y-6" data-testid="reward-store">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold">Reward Store</h2>
        <div className="flex items-center justify-center gap-2 text-lg">
          <Star className="w-5 h-5 fill-current text-yellow-500" />
          <span className="font-semibold" data-testid="store-stars-balance">{stars} Stars</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {rewards.map((reward) => {
          const isActive = activeRewardId === reward.id;
          const canAfford = stars >= reward.cost;
          
          return (
            <Card 
              key={reward.id} 
              className={`hover-elevate transition-all ${
                isActive ? 'ring-2 ring-primary border-primary/50' : ''
              }`}
              data-testid={`reward-card-${reward.id}`}
            >
              <CardContent className="p-4 space-y-3">
                {/* Reward Image */}
                <div className="aspect-square rounded-lg overflow-hidden bg-muted relative">
                  <img 
                    src={reward.image} 
                    alt={reward.name}
                    className="w-full h-full object-cover"
                  />
                  {isActive && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-primary text-primary-foreground">
                        <Check className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    </div>
                  )}
                </div>

                {/* Reward Info */}
                <div className="text-center space-y-2">
                  <h3 className="font-semibold text-sm" data-testid={`reward-name-${reward.id}`}>
                    {reward.name}
                  </h3>
                  <Badge 
                    variant="outline" 
                    className={`${canAfford ? 'text-chart-1 border-chart-1' : ''}`}
                    data-testid={`reward-cost-${reward.id}`}
                  >
                    <Star className="w-3 h-3 mr-1 fill-current text-yellow-500" />
                    {reward.cost} Stars
                  </Badge>
                </div>

                {/* Actions */}
                <div className="space-y-2">
                  {!isActive && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => onSetActive(reward.id)}
                      data-testid={`button-set-active-${reward.id}`}
                    >
                      Set as Goal
                    </Button>
                  )}
                  
                  <Button
                    size="sm"
                    className="w-full"
                    disabled={!canAfford}
                    onClick={() => onRedeem(reward.id)}
                    data-testid={`button-redeem-${reward.id}`}
                  >
                    {canAfford ? (
                      <>
                        <Gift className="w-4 h-4 mr-2" />
                        Redeem Now
                      </>
                    ) : (
                      `Need ${reward.cost - stars} more ⭐`
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}