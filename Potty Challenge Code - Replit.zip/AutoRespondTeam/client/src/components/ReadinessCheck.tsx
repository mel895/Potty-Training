import { Check, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type ReadinessCriteria } from "@shared/schema";

interface ReadinessCheckProps {
  readiness: ReadinessCriteria;
  onUpdateReadiness: (criteria: keyof ReadinessCriteria, value: boolean) => void;
  onNext: () => void;
}

const criteriaList = [
  { key: "canStayDry" as const, label: "They Can Stay Dry for Half an Hour at a Time" },
  { key: "canFollowInstructions" as const, label: "Can Follow 1 to 2 Step Instructions" },
  { key: "canRecognizeAccidents" as const, label: "They Can Recognize When They Have Had an Accident" },
  { key: "canSitForOneMinute" as const, label: "Can Sit for 1 Minute at a Time" },
  { key: "canTellWetFromDry" as const, label: "They Can Tell The Difference Being Wet from Dry" },
  { key: "canPullPantsUpDown" as const, label: "They Can Pull-Up and Lower Pants Independently" },
];

export default function ReadinessCheck({ readiness, onUpdateReadiness, onNext }: ReadinessCheckProps) {
  const allChecked = Object.values(readiness).every(Boolean);

  return (
    <div className="space-y-6" data-testid="readiness-assessment">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-foreground">Readiness Assessment</h2>
        <p className="text-muted-foreground">Check off the skills your child has mastered</p>
      </div>

      <div className="space-y-4">
        {criteriaList.map((criteria, index) => (
          <Card key={criteria.key} className="hover-elevate">
            <CardContent className="p-4">
              <Button
                variant="ghost"
                className="w-full justify-start text-left p-0 h-auto"
                onClick={() => onUpdateReadiness(criteria.key, !readiness[criteria.key])}
                data-testid={`criteria-${criteria.key}`}
              >
                <div className="flex items-start gap-4 w-full">
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mt-1 ${
                    readiness[criteria.key] 
                      ? 'bg-chart-1 text-white' 
                      : 'bg-muted border-2 border-border'
                  }`}>
                    {readiness[criteria.key] ? <Check className="w-5 h-5" /> : <span className="text-lg font-bold">{index + 1}</span>}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-foreground">{criteria.label}</h3>
                  </div>
                </div>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {allChecked && (
        <div className="text-center space-y-4">
          <div className="p-4 bg-chart-1/10 rounded-lg border border-chart-1/20">
            <div className="flex items-center justify-center gap-2 text-chart-1">
              <Check className="w-6 h-6" />
              <span className="font-semibold">Great! Your child is ready for potty training!</span>
            </div>
          </div>
          <Button 
            onClick={onNext} 
            size="lg" 
            className="w-full max-w-md"
            data-testid="button-next-to-rewards"
          >
            Choose Your Reward
          </Button>
        </div>
      )}
    </div>
  );
}