import { Check } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { type ReadinessCriteria } from "@shared/schema";

interface ReadinessSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  readiness: ReadinessCriteria;
  onUpdateReadiness: (criteria: keyof ReadinessCriteria, value: boolean) => void;
}

const criteriaList = [
  { key: "canStayDry" as const, label: "They Can Stay Dry for Half an Hour at a Time" },
  { key: "canFollowInstructions" as const, label: "Can Follow 1 to 2 Step Instructions" },
  { key: "canRecognizeAccidents" as const, label: "They Can Recognize When They Have Had an Accident" },
  { key: "canSitForOneMinute" as const, label: "Can Sit for 1 Minute at a Time" },
  { key: "canTellWetFromDry" as const, label: "They Can Tell The Difference Being Wet from Dry" },
  { key: "canPullPantsUpDown" as const, label: "They Can Pull-Up and Lower Pants Independently" },
];

export default function ReadinessSheet({ 
  open, 
  onOpenChange, 
  readiness, 
  onUpdateReadiness 
}: ReadinessSheetProps) {
  const completedCount = Object.values(readiness).filter(Boolean).length;
  const totalCount = Object.values(readiness).length;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-md" data-testid="readiness-sheet">
        <SheetHeader>
          <SheetTitle>Readiness Assessment</SheetTitle>
          <SheetDescription>
            Check off the skills your child has mastered ({completedCount}/{totalCount} completed)
          </SheetDescription>
        </SheetHeader>
        
        <div className="space-y-4 mt-6">
          {criteriaList.map((criteria, index) => (
            <div key={criteria.key} className="space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start text-left p-3 h-auto hover-elevate"
                onClick={() => onUpdateReadiness(criteria.key, !readiness[criteria.key])}
                data-testid={`criteria-${criteria.key}`}
              >
                <div className="flex items-start gap-3 w-full">
                  <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center mt-1 ${
                    readiness[criteria.key] 
                      ? 'bg-chart-1 text-white' 
                      : 'bg-muted border-2 border-border'
                  }`}>
                    {readiness[criteria.key] ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <span className="text-sm font-bold">{index + 1}</span>
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm leading-relaxed">
                      {criteria.label}
                    </p>
                  </div>
                </div>
              </Button>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t">
          {completedCount === totalCount ? (
            <div className="p-3 bg-chart-1/10 rounded-lg border border-chart-1/20 text-center">
              <div className="flex items-center justify-center gap-2 text-chart-1">
                <Check className="w-5 h-5" />
                <span className="font-semibold">Ready for potty training!</span>
              </div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center">
              Complete all criteria to be ready for potty training
            </p>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}