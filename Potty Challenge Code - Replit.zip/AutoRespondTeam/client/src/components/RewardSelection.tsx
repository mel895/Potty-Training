import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type Reward } from "@shared/schema";

// Import reward images
import dinnerImage from "@assets/generated_images/Family_dinner_reward_27c37eee.png";
import tvImage from "@assets/generated_images/Extra_TV_time_reward_d1fa939d.png";
import bedtimeImage from "@assets/generated_images/Bedtime_story_reward_5136fab8.png";
import aloneTimeImage from "@assets/generated_images/Alone_time_with_mom_9e8392e6.png";
import iceCreamImage from "@assets/generated_images/Ice_cream_treat_reward_de19c07a.png";
import movieImage from "@assets/generated_images/Movie_coupon_reward_a9c46cf4.png";

interface RewardSelectionProps {
  selectedReward?: Reward;
  onSelectReward: (reward: Reward) => void;
  onNext: () => void;
  onBack: () => void;
}

const rewardOptions: Reward[] = [
  { id: "dinner", name: "Family Dinner", image: dinnerImage, selected: false },
  { id: "tv", name: "Extra TV Time", image: tvImage, selected: false },
  { id: "bedtime", name: "Bedtime Story", image: bedtimeImage, selected: false },
  { id: "alone-time", name: "Alone Time with Mom", image: aloneTimeImage, selected: false },
  { id: "ice-cream", name: "Ice Cream Treat", image: iceCreamImage, selected: false },
  { id: "movie", name: "Movie Coupon", image: movieImage, selected: false },
];

export default function RewardSelection({ selectedReward, onSelectReward, onNext, onBack }: RewardSelectionProps) {
  return (
    <div className="space-y-6" data-testid="reward-selection">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-foreground">Choose Your Reward</h2>
        <p className="text-muted-foreground">Pick something special for when your child stays dry!</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {rewardOptions.map((reward) => (
          <Card 
            key={reward.id} 
            className={`cursor-pointer hover-elevate transition-all ${
              selectedReward?.id === reward.id 
                ? 'ring-2 ring-primary border-primary/50' 
                : ''
            }`}
            onClick={() => onSelectReward(reward)}
            data-testid={`reward-${reward.id}`}
          >
            <CardContent className="p-3 text-center space-y-2">
              <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                <img 
                  src={reward.image} 
                  alt={reward.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-medium text-sm text-foreground">{reward.name}</h3>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex gap-4 justify-center">
        <Button 
          variant="outline" 
          onClick={onBack}
          data-testid="button-back-to-readiness"
        >
          Back
        </Button>
        {selectedReward && (
          <Button 
            onClick={onNext} 
            size="lg"
            data-testid="button-start-tracking"
          >
            Start Tracking
          </Button>
        )}
      </div>
    </div>
  );
}