import { useState, useEffect } from "react";
import { ClipboardCheck, Store } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { type AppState, type ReadinessCriteria, type TimerState, TARGET_CHECKS } from "@shared/schema";

// Components
import OverviewProgressBars from "@/components/OverviewProgressBars";
import TimerCard from "@/components/TimerCard";
import ActiveRewardCard from "@/components/ActiveRewardCard";
import ReadinessSheet from "@/components/ReadinessSheet";
import RewardStoreGrid from "@/components/RewardStoreGrid";

// Import reward images
import dinnerImage from "@assets/generated_images/Family_dinner_reward_27c37eee.png";
import tvImage from "@assets/generated_images/Extra_TV_time_reward_d1fa939d.png";
import bedtimeImage from "@assets/generated_images/Bedtime_story_reward_5136fab8.png";
import aloneTimeImage from "@assets/generated_images/Alone_time_with_mom_9e8392e6.png";
import iceCreamImage from "@assets/generated_images/Ice_cream_treat_reward_de19c07a.png";
import movieImage from "@assets/generated_images/Movie_coupon_reward_a9c46cf4.png";

export default function Home() {
  const { toast } = useToast();
  const [readinessSheetOpen, setReadinessSheetOpen] = useState(false);
  
  // Check for short timer parameter for testing
  const urlParams = new URLSearchParams(window.location.search);
  const shortTimer = urlParams.has('shortTimer');
  const timerDuration = shortTimer ? 5 : 10 * 60; // 5 seconds for testing, 10 minutes normal
  
  // Default app state
  const defaultAppState: AppState = {
    childName: "",
    readiness: {
      canStayDry: false,
      canFollowInstructions: false,
      canRecognizeAccidents: false,
      canSitForOneMinute: false,
      canTellWetFromDry: false,
      canPullPantsUpDown: false,
    },
    checks: Array.from({ length: TARGET_CHECKS }, (_, i) => ({
      checkNumber: i + 1,
      timestamp: new Date(),
      isCompleted: false
    })),
    timer: {
      isRunning: false,
      currentCheck: 1,
      secondsLeft: timerDuration,
    },
    rewardsCatalog: [
      { id: "dinner", name: "Family Dinner", image: dinnerImage, cost: 3 },
      { id: "tv", name: "Extra TV Time", image: tvImage, cost: 2 },
      { id: "bedtime", name: "Bedtime Story", image: bedtimeImage, cost: 1 },
      { id: "alone-time", name: "Alone Time with Mom", image: aloneTimeImage, cost: 4 },
      { id: "ice-cream", name: "Ice Cream Treat", image: iceCreamImage, cost: 5 },
      { id: "movie", name: "Movie Coupon", image: movieImage, cost: 8 },
    ],
    activeRewardId: "ice-cream", // Default active reward
    stars: 3,
    redeemedRewards: [],
  };

  // Fetch app state from backend
  const { data: appState, isLoading, error } = useQuery<AppState | null>({
    queryKey: ['/api/state'],
  });

  // Initialize app state if it doesn't exist
  const initializeStateMutation = useMutation({
    mutationFn: async (state: AppState) => {
      const response = await apiRequest('POST', '/api/state', state);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/state'] });
    },
  });

  // Initialize with default state if backend returns null
  useEffect(() => {
    if (!isLoading && appState === null && !initializeStateMutation.isPending) {
      console.log("Attempting to initialize with state:", defaultAppState);
      initializeStateMutation.mutate(defaultAppState);
    }
  }, [isLoading, appState, initializeStateMutation]);

  // Use default state while loading or if no data exists yet  
  const currentAppState: AppState = appState ?? defaultAppState;

  // Get active reward
  const activeReward = currentAppState.rewardsCatalog.find(r => r.id === currentAppState.activeRewardId);

  // Mutations for backend updates
  const updateReadinessMutation = useMutation({
    mutationFn: async (readiness: ReadinessCriteria) => {
      const response = await apiRequest('PATCH', '/api/readiness', readiness);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/state'] });
    },
  });

  const updateTimerMutation = useMutation({
    mutationFn: async (timer: TimerState) => {
      const response = await apiRequest('PATCH', '/api/timer', timer);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/state'] });
    },
  });

  const updateCheckMutation = useMutation({
    mutationFn: async ({ checkNumber, isDry }: { checkNumber: number; isDry: boolean }) => {
      const response = await apiRequest('PATCH', `/api/check/${checkNumber}`, { isDry });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/state'] });
    },
  });

  const updateStarsMutation = useMutation({
    mutationFn: async (stars: number) => {
      const response = await apiRequest('PATCH', '/api/stars', { stars });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/state'] });
    },
  });

  const setActiveRewardMutation = useMutation({
    mutationFn: async (rewardId: string) => {
      const response = await apiRequest('PATCH', '/api/active-reward', { rewardId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/state'] });
    },
  });

  const redeemRewardMutation = useMutation({
    mutationFn: async (rewardId: string) => {
      const response = await apiRequest('POST', `/api/redeem/${rewardId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/state'] });
    },
  });

  // Handle readiness updates
  const handleUpdateReadiness = (criteria: keyof ReadinessCriteria, value: boolean) => {
    const updatedReadiness = { ...currentAppState.readiness, [criteria]: value };
    updateReadinessMutation.mutate(updatedReadiness);
  };

  // Handle timer updates
  const handleUpdateTimer = (updates: Partial<TimerState>) => {
    const updatedTimer = { ...currentAppState.timer, ...updates };
    updateTimerMutation.mutate(updatedTimer);
  };

  // Handle check results (Dry/Wet)
  const handleCheckResult = (isDry: boolean) => {
    const currentCheck = currentAppState.timer.currentCheck;
    
    updateCheckMutation.mutate({ checkNumber: currentCheck, isDry });

    // Update stars if dry
    if (isDry) {
      updateStarsMutation.mutate(currentAppState.stars + 1);
    }

    toast({
      title: isDry ? "Great job! 🎉" : "That's okay!",
      description: isDry 
        ? `Check ${currentCheck} was dry! You earned 1 star ⭐` 
        : `Check ${currentCheck} was wet. Keep trying!`,
    });
  };

  // Handle setting active reward
  const handleSetActiveReward = (rewardId: string) => {
    setActiveRewardMutation.mutate(rewardId);
    toast({
      title: "Goal Updated! 🎯",
      description: `${currentAppState.rewardsCatalog.find(r => r.id === rewardId)?.name} is now your active goal`,
    });
  };

  // Handle redeeming rewards
  const handleRedeemReward = (rewardId: string) => {
    const reward = currentAppState.rewardsCatalog.find(r => r.id === rewardId);
    if (!reward || currentAppState.stars < reward.cost) return;

    // Play celebration sound for reward redemption
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Play a celebratory fanfare
      oscillator.frequency.setValueAtTime(523, audioContext.currentTime); // C5
      oscillator.frequency.setValueAtTime(659, audioContext.currentTime + 0.15); // E5
      oscillator.frequency.setValueAtTime(784, audioContext.currentTime + 0.3); // G5
      oscillator.frequency.setValueAtTime(1047, audioContext.currentTime + 0.45); // C6
      oscillator.type = 'triangle';
      
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.05);
      gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.8);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.8);
      
      // Clean up audio context after sound completes
      setTimeout(() => {
        audioContext.close().catch(() => {});
      }, 900);
    } catch (error) {
      console.log('Audio celebration not available');
    }

    // Redeem the reward
    redeemRewardMutation.mutate(rewardId);
    
    // Update stars count
    updateStarsMutation.mutate(currentAppState.stars - reward.cost);

    // Clear active reward if this was the active one
    if (currentAppState.activeRewardId === rewardId) {
      setActiveRewardMutation.mutate("");
    }

    toast({
      title: "Reward Redeemed! 🎁",
      description: `Enjoy your ${reward.name}!`,
    });
  };

  // Show loading state while initializing
  if (isLoading || (!appState && initializeStateMutation.isPending)) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Loading The Potty Challenge...</h1>
          <p className="text-muted-foreground">Preparing your potty training dashboard</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-foreground">The Potty Challenge</h1>
            <p className="text-muted-foreground">Your potty training dashboard</p>
          </div>
          <Button
            variant="outline"
            onClick={() => setReadinessSheetOpen(true)}
            data-testid="button-eligibility"
          >
            <ClipboardCheck className="w-4 h-4 mr-2" />
            Eligibility
          </Button>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
            <TabsTrigger value="dashboard" data-testid="tab-dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="store" data-testid="tab-store">
              <Store className="w-4 h-4 mr-2" />
              Store
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column - Progress Overview */}
              <div className="lg:col-span-1">
                <OverviewProgressBars 
                  readiness={currentAppState.readiness}
                  checks={currentAppState.checks}
                  stars={currentAppState.stars}
                  activeRewardCost={activeReward?.cost}
                  activeRewardName={activeReward?.name}
                />
              </div>

              {/* Middle Column - Timer */}
              <div className="lg:col-span-1">
                <TimerCard 
                  timer={currentAppState.timer}
                  onUpdateTimer={handleUpdateTimer}
                  onCheckResult={handleCheckResult}
                />
              </div>

              {/* Right Column - Active Reward */}
              <div className="lg:col-span-1">
                <ActiveRewardCard 
                  activeReward={activeReward}
                  stars={currentAppState.stars}
                  onChangeReward={() => {
                    const storeTab = document.querySelector('[data-testid="tab-store"]') as HTMLElement;
                    storeTab?.click();
                  }}
                  onRedeem={activeReward ? () => handleRedeemReward(activeReward.id) : undefined}
                />
              </div>
            </div>
          </TabsContent>

          {/* Store Tab */}
          <TabsContent value="store">
            <RewardStoreGrid 
              rewards={currentAppState.rewardsCatalog}
              stars={currentAppState.stars}
              activeRewardId={currentAppState.activeRewardId}
              onSetActive={handleSetActiveReward}
              onRedeem={handleRedeemReward}
            />
          </TabsContent>
        </Tabs>

        {/* Readiness Sheet */}
        <ReadinessSheet 
          open={readinessSheetOpen}
          onOpenChange={setReadinessSheetOpen}
          readiness={currentAppState.readiness}
          onUpdateReadiness={handleUpdateReadiness}
        />
      </div>
    </div>
  );
}