import { z } from "zod";

// Constants
export const TARGET_CHECKS = 3;

// Readiness criteria for potty training
export const readinessCriteriaSchema = z.object({
  canStayDry: z.boolean(),
  canFollowInstructions: z.boolean(), 
  canRecognizeAccidents: z.boolean(),
  canSitForOneMinute: z.boolean(),
  canTellWetFromDry: z.boolean(),
  canPullPantsUpDown: z.boolean(),
});

// Available reward options
export const rewardSchema = z.object({
  id: z.string(),
  name: z.string(),
  image: z.string(),
  cost: z.number(), // stars required to redeem
});

// Wet/dry check entry
export const wetDryCheckSchema = z.object({
  checkNumber: z.number(),
  timestamp: z.coerce.date(),
  isDry: z.boolean().optional(),
  isCompleted: z.boolean(),
});

// Timer state
export const timerStateSchema = z.object({
  isRunning: z.boolean(),
  currentCheck: z.number(),
  secondsLeft: z.number(),
});

// Redeemed reward entry
export const redeemedRewardSchema = z.object({
  rewardId: z.string(),
  redeemedAt: z.coerce.date(),
});

// Main app state
export const appStateSchema = z.object({
  childName: z.string(),
  readiness: readinessCriteriaSchema,
  checks: z.array(wetDryCheckSchema),
  timer: timerStateSchema,
  rewardsCatalog: z.array(rewardSchema),
  activeRewardId: z.string().optional(),
  stars: z.number(),
  redeemedRewards: z.array(redeemedRewardSchema),
});

export type ReadinessCriteria = z.infer<typeof readinessCriteriaSchema>;
export type Reward = z.infer<typeof rewardSchema>;
export type WetDryCheck = z.infer<typeof wetDryCheckSchema>;
export type TimerState = z.infer<typeof timerStateSchema>;
export type RedeemedReward = z.infer<typeof redeemedRewardSchema>;
export type AppState = z.infer<typeof appStateSchema>;
