import { type AppState, type ReadinessCriteria, type TimerState, type WetDryCheck, TARGET_CHECKS } from "@shared/schema";

// Storage interface for potty training app
export interface IStorage {
  getAppState(): Promise<AppState | undefined>;
  updateAppState(appState: AppState): Promise<AppState>;
  updateReadiness(readiness: ReadinessCriteria): Promise<ReadinessCriteria>;
  updateTimer(timer: TimerState): Promise<TimerState>;
  updateCheck(checkNumber: number, isDry: boolean): Promise<WetDryCheck>;
  updateStars(stars: number): Promise<number>;
  setActiveReward(rewardId: string | undefined): Promise<string | undefined>;
  redeemReward(rewardId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private appState: AppState | undefined;

  constructor() {
    this.appState = undefined;
  }

  async getAppState(): Promise<AppState | undefined> {
    return this.appState;
  }

  async updateAppState(appState: AppState): Promise<AppState> {
    this.appState = appState;
    return appState;
  }

  async updateReadiness(readiness: ReadinessCriteria): Promise<ReadinessCriteria> {
    if (!this.appState) {
      // Initialize with default state if it doesn't exist
      await this.initializeDefaultState();
    }
    if (this.appState) {
      this.appState.readiness = readiness;
    }
    return readiness;
  }

  async updateTimer(timer: TimerState): Promise<TimerState> {
    if (!this.appState) {
      await this.initializeDefaultState();
    }
    if (this.appState) {
      this.appState.timer = timer;
    }
    return timer;
  }

  private async initializeDefaultState(): Promise<void> {
    if (!this.appState) {
      // Import reward images paths (these would be the same as in frontend)
      const defaultState: AppState = {
        childName: "",
        readiness: {
          canStayDry: false,
          canFollowInstructions: false,
          canRecognizeAccidents: false,
          canSitForOneMinute: false,
          canTellWetFromDry: false,
          canPullPantsUpDown: false,
        },
        checks: Array.from({ length: TARGET_CHECKS }, (_, i) => ({
          checkNumber: i + 1,
          timestamp: new Date(),
          isCompleted: false
        })),
        timer: {
          isRunning: false,
          currentCheck: 1,
          secondsLeft: 10 * 60, // 10 minutes
        },
        rewardsCatalog: [
          { id: "dinner", name: "Family Dinner", image: "/assets/generated_images/Family_dinner_reward_27c37eee.png", cost: 3 },
          { id: "tv", name: "Extra TV Time", image: "/assets/generated_images/Extra_TV_time_reward_d1fa939d.png", cost: 2 },
          { id: "bedtime", name: "Bedtime Story", image: "/assets/generated_images/Bedtime_story_reward_5136fab8.png", cost: 1 },
          { id: "alone-time", name: "Alone Time with Mom", image: "/assets/generated_images/Alone_time_with_mom_9e8392e6.png", cost: 4 },
          { id: "ice-cream", name: "Ice Cream Treat", image: "/assets/generated_images/Ice_cream_treat_reward_de19c07a.png", cost: 5 },
          { id: "movie", name: "Movie Coupon", image: "/assets/generated_images/Movie_coupon_reward_a9c46cf4.png", cost: 8 },
        ],
        activeRewardId: "ice-cream",
        stars: 3,
        redeemedRewards: [],
      };
      this.appState = defaultState;
    }
  }

  async updateCheck(checkNumber: number, isDry: boolean): Promise<WetDryCheck> {
    if (!this.appState) {
      await this.initializeDefaultState();
    }
    if (this.appState) {
      const checkIndex = this.appState.checks.findIndex(c => c.checkNumber === checkNumber);
      if (checkIndex !== -1) {
        this.appState.checks[checkIndex] = {
          ...this.appState.checks[checkIndex],
          isDry,
          isCompleted: true,
          timestamp: new Date()
        };
        return this.appState.checks[checkIndex];
      }
    }
    throw new Error(`Check ${checkNumber} not found`);
  }

  async updateStars(stars: number): Promise<number> {
    if (!this.appState) {
      await this.initializeDefaultState();
    }
    if (this.appState) {
      this.appState.stars = stars;
    }
    return stars;
  }

  async setActiveReward(rewardId: string | undefined): Promise<string | undefined> {
    if (!this.appState) {
      await this.initializeDefaultState();
    }
    if (this.appState) {
      this.appState.activeRewardId = rewardId;
    }
    return rewardId;
  }

  async redeemReward(rewardId: string): Promise<void> {
    if (!this.appState) {
      await this.initializeDefaultState();
    }
    if (this.appState) {
      this.appState.redeemedRewards.push({
        rewardId,
        redeemedAt: new Date()
      });
    }
  }
}

export const storage = new MemStorage();
