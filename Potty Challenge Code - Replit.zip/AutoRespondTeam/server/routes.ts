import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { appStateSchema, readinessCriteriaSchema, timerStateSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current app state
  app.get("/api/state", async (req, res) => {
    try {
      const appState = await storage.getAppState();
      res.json(appState ?? null);
    } catch (error) {
      res.status(500).json({ error: "Failed to get app state" });
    }
  });

  // Update entire app state
  app.post("/api/state", async (req, res) => {
    try {
      const validatedState = appStateSchema.parse(req.body);
      const updatedState = await storage.updateAppState(validatedState);
      res.json(updatedState);
    } catch (error) {
      console.error("POST /api/state validation error:", error);
      res.status(400).json({ 
        error: "Invalid app state data", 
        message: error instanceof Error ? error.message : String(error),
        issues: error.issues || []
      });
    }
  });


  // Update readiness criteria
  app.patch("/api/readiness", async (req, res) => {
    try {
      const validatedReadiness = readinessCriteriaSchema.parse(req.body);
      const updatedReadiness = await storage.updateReadiness(validatedReadiness);
      res.json(updatedReadiness);
    } catch (error) {
      res.status(400).json({ error: "Invalid readiness data" });
    }
  });

  // Update timer state
  app.patch("/api/timer", async (req, res) => {
    try {
      const validatedTimer = timerStateSchema.parse(req.body);
      const updatedTimer = await storage.updateTimer(validatedTimer);
      res.json(updatedTimer);
    } catch (error) {
      res.status(400).json({ error: "Invalid timer data" });
    }
  });

  // Update check result (wet/dry)
  app.patch("/api/check/:checkNumber", async (req, res) => {
    try {
      const checkNumber = parseInt(req.params.checkNumber);
      const { isDry } = req.body;
      
      if (typeof isDry !== "boolean" || isNaN(checkNumber)) {
        return res.status(400).json({ error: "Invalid check data" });
      }

      const updatedCheck = await storage.updateCheck(checkNumber, isDry);
      res.json(updatedCheck);
    } catch (error) {
      res.status(400).json({ error: "Failed to update check" });
    }
  });

  // Update stars count
  app.patch("/api/stars", async (req, res) => {
    try {
      const { stars } = req.body;
      
      if (typeof stars !== "number") {
        return res.status(400).json({ error: "Invalid stars count" });
      }

      const updatedStars = await storage.updateStars(stars);
      res.json({ stars: updatedStars });
    } catch (error) {
      res.status(400).json({ error: "Failed to update stars" });
    }
  });

  // Set active reward
  app.patch("/api/active-reward", async (req, res) => {
    try {
      const { rewardId } = req.body;
      const updatedRewardId = await storage.setActiveReward(rewardId);
      res.json({ activeRewardId: updatedRewardId });
    } catch (error) {
      res.status(400).json({ error: "Failed to set active reward" });
    }
  });

  // Redeem a reward
  app.post("/api/redeem/:rewardId", async (req, res) => {
    try {
      const { rewardId } = req.params;
      await storage.redeemReward(rewardId);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: "Failed to redeem reward" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
