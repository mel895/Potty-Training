# Design Guidelines: Potty Training Challenge App

## Design Approach
**Reference-Based Approach**: Drawing inspiration from child-friendly educational apps like ABCmouse and Khan Academy Kids, combined with parent-focused productivity tools like Headspace and Calm for the clean, reassuring aesthetic that busy parents need.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Light Mode: 220 85% 60% (cheerful blue)
- Dark Mode: 220 50% 30% (deeper blue)

**Accent Colors:**
- Success Green: 140 60% 50% 
- Warning Orange: 25 85% 60%
- Neutral Gray: 220 10% 60%

**Background Treatment:**
- Light gradients from primary blue to soft white (200 20% 95%)
- Subtle curved overlays and gentle geometric patterns
- Card-based sections with soft shadows

### Typography
**Font Family:** Inter from Google Fonts
- **Headers:** Bold (700) - 24px to 32px
- **Body Text:** Medium (500) - 16px to 18px  
- **Button Text:** Semibold (600) - 16px
- **Timer Display:** Bold (700) - 48px

### Layout System
**Spacing Units:** Tailwind units of 4, 6, and 8 (p-4, h-6, m-8)
- Generous whitespace for child-friendly interaction
- Card-based layout with rounded corners (rounded-xl)
- Responsive grid system for reward selection

### Component Library

**Navigation:**
- Progress stepper at top showing current section
- Smooth slide transitions between sections
- Large back/next buttons (min 44px touch target)

**Interactive Elements:**
- Oversized buttons with rounded corners and gentle shadows
- Checkbox cards for readiness assessment (large touch areas)
- Image-based reward selection grid with overlay labels
- Circular timer display with animated progress ring

**Data Display:**
- Achievement badges for completed milestones  
- Simple progress bars with child-friendly colors
- Timer countdown with large, clear numbers
- Status indicators using color-coded icons

**Forms:**
- Minimal input requirements
- Toggle switches instead of checkboxes where possible
- Visual feedback for all interactions

## Images
**Hero Section:** Large, warm illustration of a happy child and parent celebrating potty training success (approximately 400px height on desktop)

**Reward Selection:** Grid of 6 colorful reward images:
- Family dinner scene
- TV/tablet time  
- Bedtime story reading
- Parent-child bonding time
- Ice cream treat
- Movie night coupon

**Progress Indicators:** Simple illustrated icons for each readiness criteria and achievement badges

**Background Elements:** Subtle pattern overlays with child-friendly shapes (stars, circles) in very light opacity

## Key Design Principles
1. **Child-Centered UX:** Large touch targets, bright colors, immediate visual feedback
2. **Parent-Friendly Interface:** Clean, organized sections with clear progress tracking
3. **Encouraging Tone:** Positive reinforcement through colors, imagery, and micro-interactions
4. **Accessibility:** High contrast ratios, clear typography, intuitive navigation flow
5. **Single-Page Flow:** Smooth section transitions without page reloads, maintaining context and progress